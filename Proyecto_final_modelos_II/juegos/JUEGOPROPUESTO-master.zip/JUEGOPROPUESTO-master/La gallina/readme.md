### Ejercicios Modelos II 
EJERCICIO DE LA GALLINA


## Santiago Gómez Almeyda 20161020503
## Arthur David Sánchez 20171020073
## Kevin Borda 20171020088
